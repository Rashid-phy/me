#!/usr/bin/perl

require "../../libs/w2web.pl";
$doit=0;

&GetInput;
&GetSession;

if (!$doit) {

$OUT = <<__STOP__;
<h3>save_boltz2</h3>
<FORM ACTION="/util/saveboltz2.pl" METHOD=POST>
<INPUT TYPE=HIDDEN NAME="SID" VALUE="$SID">
<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
Save name or directory: 
$indent <INPUT NAME="savename"><br>
<br>
<INPUT TYPE=SUBMIT VALUE="save">
</FORM>

__STOP__

} else {
$OUT .= "<h3>save_boltz2 $savename</h3>";
	
	if (!$savename) {
		$OUT .= "<b>ERROR</b> no save name given!";
	} else {

		$cmdline = "save_boltz2";
		$cmdline .= " $savename";

		$OUT .= "$cmdline";

		$out = qx(cd $DIR; $cmdline);
		$OUT .= "<pre>$out</pre>" ;
	}

}

$phase=qx(cut -c1-4 $DIR/.mystep);
if($phase == 11) {
qx(echo "0" >$DIR/.mystep);
}

PrintPage("save_boltz2", $OUT);

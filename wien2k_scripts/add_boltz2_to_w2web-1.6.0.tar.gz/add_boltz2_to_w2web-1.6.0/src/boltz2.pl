#!/usr/bin/perl

require "../../libs/w2web.pl";
#$debug=1;
$spin="up";
$myspinopt="";
$name="";

&GetInput;
&GetSession;
$prefspace="scf";
&GetPrefs();

$next="continue with BoltzTraP setup ";
$nexturl="/exec/boltz2.pl?SID=$SID";
$nextinteractive=1;

$step=1;


qx(find btp2.version -size 0 -delete );
if( -e "btp2.version" ){
$umpss = qx(cut -c11-20 btp2.version );
} else{
qx( btp2 -V > btp2.version);
$umpss = qx(cut -c11-20 btp2.version );
}
$bcolor="";
sub mark {
 #$bcolor="bcolor";
 $bcolor="taskactive";
}
sub reset {
    $bcolor="";
}

$OUT .= <<__STOP__;
The present page is  Unofficial add on for w2web (v1.6.0).
<h3> Boltzmann Transport Properties (<A HREF="https://www.imc.tuwien.ac.at/index.php?id=21094" TARGET=spgrp >BoltzTraP2 </A> Version:$umpss) </h3> 
__STOP__
 
$OUT.="<TABLE >";


&InitTask();
&RequiredFile("infermi");

if ($plot) {
 
$OUT .=  <<__STOP__;
<TR><TD class="task">
<A HREF="$nexturl">Show full menu</A>
</TD></TR>
__STOP__

} else {
$OUT .=  <<__STOP__;
<TR><TD class="taskoption">
<FORM ACTION="/util/edit2.pl">
<b>Optional steps: </b><br>
__STOP__

&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__

&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="kgen">
<INPUT TYPE=SUBMIT VALUE="x kgen">
Prepare a denser k-mesh
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__

&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapw1">
$myspin
<INPUT TYPE=SUBMIT VALUE="x lapw1  $myspinopt $mypara">
Create eigenvalues at denser k-mesh 
&nbsp;
__STOP__

if($spinpol=~ /CHECKED/ && ! $PREFS{'so'} ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}

$OUT .=  <<__STOP__;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__

 if($spinpol=~ /CHECKED/ ) {
 $otherspin = "dn" if ($spin =~ /up/) ;
 $otherspin = "up" if ($spin =~ /dn/) ;
 
$OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__

&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapw1">
<INPUT TYPE=HIDDEN NAME=spin VALUE=$otherspin>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
<INPUT TYPE=SUBMIT VALUE="x lapw1  -$otherspin $mypara">
for both spins
__STOP__


if($spinpol=~ /CHECKED/ && ! $PREFS{'so'} ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}
$OUT .=  <<__STOP__;
$ni
</FORM>
__STOP__
}

if( $PREFS{'so'})  {
    $my_spinp = "no" ;
    $my_spinp = "yes" if ($spin =~ /dn/) ;
    if ($my_spinp =~ /no/) {
$OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;

$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapwso ">
<INPUT TYPE=SUBMIT VALUE="x lapwso $myspinopt $mypara">
$myspin
Create eigenvalues with spin-orbit coupling
&nbsp;
__STOP__

if($spinpol=~ /CHECKED/ ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}

$OUT .=  <<__STOP__;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__
} 
}

#----gather  the case.energy files --
&PassHiddenParms;
if ( $mypara ) {
$OUT .=  <<__STOP__;
</TD></TR>
<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__

$OUT .=  <<__STOP__;
<b> To gather the $CASE.energy_? files (outputs of parallel mode ) :</b><br>
<INPUT NAME=prog TYPE=HIDDEN VALUE="gather_energy.pl $CASE $myspinopt">
<INPUT TYPE=SUBMIT VALUE="gather_energy.pl $CASE  $myspinopt ">
$myspin
To gather the $CASE.energy$myspinorpt files  
<INPUT NAME=so TYPE=CHECKBOX $PREFS{'so'}>&nbsp;so&nbsp;
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
__STOP__
}

#//help iterpolate///
$num =1;
$e=-0.2;
$E=0.2;
$k="";
$m="1";

&PassHiddenParms;
$OUT .=  <<__STOP__;
</FORM>
</TD ></TR>
<TR><TD class="task" >
<b >BoltzTraP steps:</b><br>
 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp   
&nbsp;&nbsp;&nbsp;<SELECT NAME="help">
<OPTION  >
clic to show the positional and optional arguments of "btp2 interpolate".
<OPTION  >
-n NWORKERS: number of processes to span for parallel operations (default: 1)
<OPTION  >
-Emin: bands with points below this energy will be ignored(default: -0.2) (Emin in Ha, relative to the Fermi level)
<OPTION >
-Emax:bands with points above this energy will be ignored (default: 0.2) (Emax in Ha, relative to the Fermi level)
<OPTION >
-KPOINTS:&nbsp approximate number of irreducible k points to be used in the interpolation (default: None)
<OPTION >
-MULTIPLIER:&nbsp enhancement factor for the number of irreducible k points in the interpolation vs the DFT input (default: None)
</SELECT>
<FORM ACTION=/exec/b_executor.pl METHOD=POST>
__STOP__

#////////////////////////////////////////interpolate //////////////////////////
if      ( -e "$DIR/btp2input" ) {
$num =qx(grep NWORKERS=     $DIR/btp2input | awk '{ print \$2}' );
$e   =qx(grep Emin=         $DIR/btp2input | awk '{ print \$2}' );
$E   =qx(grep Emax=         $DIR/btp2input | awk '{ print \$2}' );
$k   =qx(grep Kpoint=       $DIR/btp2input | awk '{ print \$2}' );
$m   =qx(grep Multiplier=   $DIR/btp2input | awk '{ print \$2}' );
}
&PassHiddenParms;
if( -e "$DIR/.mystep" ) {
$step   =qx(cut -c1-4 $DIR/.mystep );
}
$mystep=1;
 if( $step == $mystep){&mark};
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="btp2 -vv ">
<INPUT NAME=prog TYPE=HIDDEN VALUE="interpolate">
<INPUT TYPE=SUBMIT VALUE="btp2 interpolate "  class="$bcolor" bgcolor="$green"> -n : 
<input type=text size=2 name=num  value="$num" > 
<input type=hidden size=1 name=INPUT1  value='$CASE.bt2' >-Emin:
<input type=text    size=5 name=INPUT2 value="$e" >-Emax: 
<input type=text    size=5 name=INPUT3 value="$E" >  Kpoints:  
<input type=text    size=5 name=INPUT4 value= "$k"> <b> OR</b> Multiplier: 
<input type=text    size=3 name=INPUT5 value="$m" > 
<input type=HIDDEN  size=5 name=INPUT6 value='./' >

<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__

&reset;

$mystep = 2;
&mark if ($step == $mystep);
#//help itergrate/////////////////////////////
&PassHiddenParms;
$OUT .=  <<__STOP__;
</TD></TR>
<TR><TD class="task">
<b>Computing the Onsager coefficients:</b><br>&nbsp;&nbsp;&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp <SELECT NAME="help">
<OPTION  >
clic to show the positional and optional arguments of "btp2 integrate".
<OPTION  >
temperature: single temperature, range minT:maxT:deltaT, or comma separated list of temperatures and ranges [K]
<OPTION  >
-b BINS, --bins BINS  number of bins for the DOS (default: None)
<OPTION  >
-t, --tau : work under a uniform-relaxation-time approximation (default: uniform_tau)
<OPTION  >
-l, --lambda : work under a uniform-mean-free-path approximation (default: uniform_tau)
<OPTION  >
 -s SCISSOR, value of the gap, in eV, to be achieved by shifting the conduction bands (default: None)
<OPTION  >
The reference for the chemical potential is electroneutrality.
</SELECT>

<FORM ACTION=/exec/b_executor.pl METHOD=POST>
__STOP__


#////////////////////////////////////////integrate /////////////////
$num     =1;
$temp    ="100:1000:100";
$b       ="";
$scissor ="";

if( -e "$DIR/btp2input2" ) {
$num     =qx(grep NWORKERS=     $DIR/btp2input2 | awk '{ print \$2}' );
$temp    =qx(grep TEMPERATUR=   $DIR/btp2input2 | awk '{ print \$2}' );
$b       =qx(grep BINS=         $DIR/btp2input2 | awk '{ print \$2}' );
$scissor =qx(grep SCISSOR=      $DIR/btp2input2 | awk '{ print \$2}' );
}
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="btp2 -vv ">
<INPUT NAME=prog TYPE=HIDDEN VALUE="integrate">
<INPUT TYPE=SUBMIT VALUE="btp2 integrate " class="$bcolor" > -n:
<input type=text    size=2  name="num"    value='$num' >
<input type=hidden  size=10 name="INPUT1" value='$CASE.bt2' >Temperature:
<input type=text    size=12 name="INPUT5" value="$temp" >BINS:
<input type=text    size=2  name="INPUT2" value="$b" >  SCISSOR:
<input type=text    size=2  name="INPUT4" value="$scissor" > <b> Tau <b/> 
<input TYPE=radio           name="INPUT3" value=" -t "  ><b> Lambda </b>   
<input TYPE=radio           name="INPUT3" value=" -l " > <b> default </b> 
<input TYPE=radio           name="INPUT3" value="" checked  >
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
__STOP__

&PassHiddenParms;
&reset;
$mystep = 3;
&mark if ($step == $mystep);

$OUT .=  <<__STOP__;
</FORM>
<br><br>
<FORM ACTION="/util/edit2.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.trace" TYPE=HIDDEN>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE=SUBMIT VALUE="View  $CASE.trace" class="$bcolor" >
view .trace   file )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>

__STOP__

&reset;


#</TD></TR>
#<TR><TD class="task">


}

######   plot  ###############################################

if($plot){
	$OUT .= <<__STOP__;
<b>We are in plot mode</b><br>
<TR><TD class="task">
__STOP__
	if($doit) {

		$plotfile="$tempdir/$SID-$$";
		$infile="$DIR/$CASE.";
		$titline=1;
		$delline=0;
                       
                        $col3="";
                        $col4="";
                        $col5="";
                        $col6="";
                        $col7="";
                        $col8="";
                        $col9="";
                        $col10="";
                        $col11="";
                        $col12="";
                        $col13="";
     if ($col =~ /3/) {
                } elsif ($col =~ /3/) {                
		        $col3="selected";
		} elsif ($col =~ /4/) {
                        $col4="selected";
		} elsif ($col =~ /5/) {
                        $col5="selected";
		} elsif ($col =~ /6/) {
                        $col6="selected";
		} elsif ($col =~ /7/) {
                        $col7="selected";
                } elsif ($col =~ /8/) {
                        $col8="selected";
		} elsif ($col =~ /9/) {
                        $col9="selected";
		} elsif ($col =~ /10/) {
                        $col10="selected";
		} elsif ($col =~ /11/) {
                        $col11="selected";
                } elsif ($col =~ /12/) {
                        $col12="selected";
               } elsif ($col =~ /13/) {
                        $col13="selected";
		} 
     if($edoit) {
			$ecol1="";
                        $ecol2="";
            if ($ecol =~ /1/) {
                        $ecol1="selected";
	        } elsif ($ecol =~ /2/) {
                        $ecol2="selected"; 
                        }
		
        }		
		
		
		
		
        $seltrace="";
		$seltracedoping="";
		
    if ($selfile =~ /trace/) {
			$infile.="trace";
			$titline=1;
			$delline=1;
            $seltrace="selected";
		} elsif ($selfile =~ /dope/) {
			$infile.="dope.trace";
			$titline=1;
			$delline=1;
        $seltrace="selected";
		}

	
		$test = qx(wc -l $infile);
		if ($test == 0) {
			$OUT .= "$infile is empty - no plot produced";
		} else {

			$tmp1 = "$DIR/:bolt1";
			$tmp2 = "$DIR/:bolt2";
                  if ($ecol == 1) {
			$units  = "Ry";
			$xlabel = "chemical potential  [Ry]";
			$axis   = "yzeroaxis";
		} else {
		        $units  = "°K";
			$xlabel = "Temperature [°K]";
			$axis   = "yzeroaxis";
		
		
	           }
			$umps = qx(sed "1,${delline}d" $infile >$tmp1);
			$tmp  = qx(cat $infile | head -$titline | tail -1|cut -c3-8,15-192);
			@ylabels = split(" ",$tmp);
			$ylabel = $ylabels[$col-1];
			$title = "$infile column $col";

    unless(open(FILE,">$tmp2")) {
      &CGIError("Can't write file $fname.\n");
      exit;
    }
    print FILE <<__STOP__;
show all
set terminal png
set output '$plotfile.png'
set title '$title'
set style data lines
set xrange [$xmin:$xmax]
set yrange [$ymin:$ymax]
set xlabel "$xlabel"
set ylabel "$ylabel"

set $axis
$plotoptions
plot "$tmp1" using $ecol:$col  
set terminal postscript
set output '$plotfile.ps'
replot
__STOP__
			close(FILE);
			$umps = qx(cd $DIR;gnuplot $tmp2 2>&1);
			$OUT .= "<br><IMG SRC=/tmp/$SID-$$.png><br clear=all><br>";
			$OUT .= "<A HREF=/tmp/$SID-$$.ps>Download hardcopy in PostScript format</A
>";

	
		    }
#		$OUT .= $myform1;
#		&PassHiddenParms;
#		$OUT .= $myform2
	}
$myform1 =  <<__STOP__;
<FORM ACTION=/exec/boltz2.pl METHOD=POST>
__STOP__
$myform2 =  <<__STOP__;
<SELECT NAME="selfile">
<option $seltrace value="trace">$CASE.trace
<option $seltracedoping value="dope">$CASE.dope.trace

</SELECT>
<SELECT NAME="ecol">
<option $ecol1 value=1>1
<option $ecol2 value=2>2
</SELECT>
<INPUT TYPE=hidden NAME=edoit VALUE="1">


</SELECT>
<SELECT NAME="col">
<option $col3  value=3>03
<option $col4  value=4>04
<option $col5  value=5>05
<option $col6  value=6>06
<option $col7  value=7>07
<option $col8  value=8>08
<option $col9  value=9>09
<option $col10 value=10>10
<option $col11 value=11>11
<option $col12 value=12>12
<option $col13 value=13>13
</SELECT>
<INPUT TYPE=hidden NAME=doit VALUE="1">
<INPUT TYPE=hidden NAME=plot VALUE="1">
<INPUT TYPE=SUBMIT VALUE="plot">


Plot Transport properties
<br>
Set ranges (optional):
<br>
xmin=<INPUT NAME=xmin VALUE="$xmin" SIZE=5>
xmax=<INPUT NAME=xmax VALUE="$xmax" SIZE=5>
ymin=<INPUT NAME=ymin VALUE="$ymin" SIZE=5>
ymax=<INPUT NAME=ymax VALUE="$ymax" SIZE=5>
<INPUT TYPE=HIDDEN NAME="spin" VALUE="$spin">
</FORM>
</TD></TR>
__STOP__

#old doit beginn
# else {
		$OUT .= $myform1;
		&PassHiddenParms;
		$OUT .= $myform2

#	}
} else {
#<TR><TD class="task">
$mystep = 4;


	$OUT .= <<__STOP__;
</TD></TR>
<TR><TD class="task">
<FORM ACTION=/exec/boltz2.pl METHOD=POST>
<b>Plot the Onsager coefficients:</b><br>
__STOP__
&PassHiddenParms;
    opendir(DIR1, $DIR);
    @files = sort(readdir(DIR1));
    closedir(DIR1);
$OUT .=  <<__STOP__;
<INPUT TYPE=hidden NAME=plot VALUE="1">
$myspin
<INPUT TYPE=SUBMIT VALUE="plot   $CASE.trace" class="$bcolor">
Plot Boltzmann Transport Properties using "gnuplot" &nbsp;&nbsp;&nbsp;  <br> 
__STOP__


  
&PassHiddenParms;
$OUT .=  <<__STOP__;
</FORM>
 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<SELECT NAME="help">
<OPTION  >
clic to show the positional and optional arguments of "btp2 plot".
<OPTION  >
-c COMPONENTS:components to be plotted in the case of tensor quantitites (default: None)
<OPTION  >
-u: use the chemical potential as the abscissa in the plots (default: mu)
<OPTION  >
-T: use the temperature as the abscissa in the plots (default: mu)
<OPTION  >
-s SUBSAMPLE : plot a curve only for one out of each SUBSAMPLE values of the variable not chosen as the abscissa (default:1)
<OPTION  >
Quantity to be plotted: cv,n,DOS,sigma,S,kappae,L,PF,RH
</SELECT>
<FORM ACTION=/exec/b_executor.pl METHOD=POST>
__STOP__

#btp2 plot [-h] [-c COMPONENTS] [-u | -T] [-s SUBSAMPLE]
#                 btj_file {cv,n,DOS,sigma,S,kappae,L,PF,RH}

#////////////////////////////////////////integrate /////////////////
&PassHiddenParms;

$mystep = 4;
 if ($step == $mystep){&mark};

 
$OUT .=  <<__STOP__;

<INPUT NAME=precmd TYPE=HIDDEN VALUE="btp2 -vv ">
<INPUT NAME=prog TYPE=HIDDEN VALUE=" plot ">
<INPUT TYPE=SUBMIT VALUE="btp2 plot " class="$bcolor"> -c

<select  type=text   name=INPUT1> 
<OPTION name="INPUT1" value='["xx"]' > [xx]
<OPTION name="INPUT1" value='["zz"]' > [zz]
<OPTION name="INPUT1" value='["yy"]' > [yy]
<OPTION name="INPUT1" value='["xx","zz"]' > [xx,zz]
<OPTION name="INPUT1" value='["xx","yy","zz"]' > [xx,yy;zz]
</SELECT> 
<b> -u </b>
<input TYPE=radio NAME="INPUT2" VALUE="-u" checked  ><b> -T </b>  
<input TYPE=radio NAME="INPUT2" VALUE="-T" > -s 
<input type=text size=3 name="INPUT3" value="2" >
<input type=hidden  name="INPUT4" value="$CASE.btj" >parameter:

<SELECT type=text  name=INPUT5  > 
<OPTION name="INPUT5" value="S" >S
<OPTION name="INPUT5" value="cv" >cv
<OPTION name="INPUT5" value="n" >n
<OPTION name="INPUT5" value="DOS" >DOS
<OPTION name="INPUT5" value="sigma" >sigma
<OPTION name="INPUT5" value="kappae" >kappae
<OPTION name="INPUT5" value="PF" >PF
<OPTION name="INPUT5" value="RH" >RH
</SELECT> 
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>
__STOP__


&reset; 






###############################"""

&PassHiddenParms;
$OUT .=  <<__STOP__;
</FORM>
</TD></TR>
<TR><TD class="task">
<b> add the doping levels:</b><br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<SELECT NAME="help">
<OPTION  >
clic to show the positional and optional arguments of "btp2 dope".
<OPTION  >
temperature: single temperature, range minT:maxT:deltaT, or comma separated list of temperatures and ranges [K]
<OPTION  >
doping_level: single doping level, range min:max:delta, or comma separated list of doping levels and ranges thereof [1/cm^3]
<OPTION  >
-b BINS, --bins BINS  number of bins for the DOS (default: None)
<OPTION  >
-t, --tau : work under a uniform-relaxation-time approximation (default: uniform_tau)
<OPTION  >
-l, --lambda : work under a uniform-mean-free-path approximation (default: uniform_tau)
<OPTION  >
 -s SCISSOR, value of the gap, in eV, to be achieved by shifting the conduction bands (default: None)
</SELECT>
</TD></TR>
<br> 
<TR><TD class="task">
<FORM ACTION=/exec/b_executor.pl METHOD=POST>
__STOP__

# btp2 dope [-h] [-p PREFIX] [-b BINS] [-t | -l]   temperature doping_level

#////////////////////////////////////////dope /////////////////
$num    =1;
$temp   ="100:500:10";
$b      ="";
$dp     ="";
$scissor="";

if( -e "$DIR/btp2input3" ) {
$num    =qx (grep NWORKERS=     $DIR/btp2input3 | awk '{ print \$2}' );
$temp   =qx (grep TEMPERATUR=   $DIR/btp2input3 | awk '{ print \$2}' );
$b      =qx (grep BINS=         $DIR/btp2input3 | awk '{ print \$2}' );
$dp     =qx (grep DOPING=       $DIR/btp2input3 | awk '{ print \$2}' );
$scissor=qx (grep SCISSOR=      $DIR/btp2input3 | awk '{ print \$2}' );
}
$mystep = 5;
 if ($step == $mystep){&mark};
&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="btp2 -vv ">
<INPUT NAME=prog TYPE=HIDDEN VALUE="dope">
<INPUT TYPE=SUBMIT VALUE="btp2 dope " class="$bcolor"> -n:
<input type=text    size=2  name=num  value="$num" > 
<input type=hidden          name="INPUT1" value='$CASE.bt2' >Temperature:
<input type=text    size=10 name="INPUT5" value="$temp" >Doping level[1/cm^3]:
<input type=text    size=10 name="INPUT6" value="$dp"  > BINS:
<input type=text    size=2  name="INPUT2" value="$b" > SCISSOR:
<input type=text    size=2  name="INPUT4" value="$scissor" ><b> Tau </b> 
<input TYPE=radio           name="INPUT3" value=" -t " > <b> Lambda </b>
<input TYPE=radio           name="INPUT3" value=" -l " > <b> default </b> 
<input TYPE=radio           name="INPUT3" value="" checked  >
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">

__STOP__

&PassHiddenParms;
&reset;
#///////// view trace ///////////////////////////////////////////////////////////////
$mystep = 6;
&mark if ($step == $mystep);
&PassHiddenParms;
$OUT .=  <<__STOP__;
</FORM>
 

<FORM ACTION="/util/edit2.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.dope.trace" TYPE=HIDDEN>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<INPUT TYPE=SUBMIT VALUE="View  $CASE.dope.trace" class="$bcolor">
( view BoltzTraP2  results in original file )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
__STOP__
#&&&&&&&&&&&&&&&&&&&&&&&&&&&plot&&&&&&&&
#      //help plot/////////////////////////////
&reset;
&PassHiddenParms;


$OUT.= <<__STOP__;
</FORM>
</TD></TR>
<TR><TD bgcolor=#F5DEB3  >
<b>Optionnel steps</b><br>
The case.trace in a new format (case.tarce2) (with fortran: FORMAT(F12.8,F10.4,F20.8,8E25.8)). The frist column is <img src="/art/E-ef.png" width=90 height=20 border=0>.</b>
</TD></TR>
<TR><TD class="task">

<FORM ACTION="/util/edit2.pl">
__STOP__
$mystep = 7;
&mark if ($step == $mystep);
$OUT .=  <<__STOP__;
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.infermi" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.infermi" class="$bcolor">
Insert Refined Fermi level in Ry  to calculate <img src="/art/E-ef.png" width=90 height=20 border=0>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
__STOP__
&reset;
$mystep = 8; 
&mark if ($step == $mystep);
$OUT.= <<__STOP__;
 </FORM>
 
<FORM ACTION=/exec/b_executor.pl METHOD=POST>
<INPUT NAME=prog TYPE=HIDDEN VALUE="calculate_trace "> 
<INPUT TYPE=SUBMIT VALUE="calculate u-uf [eV] " class="$bcolor"> output : $CASE.trace2 and $CASE.dope.trace2
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
__STOP__
&reset;

$mystep = 9;
&mark if ($step == $mystep);
&PassHiddenParms;
$OUT .=  <<__STOP__;
</FORM>
<FORM ACTION="/util/edit2.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.trace2" TYPE=HIDDEN>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<INPUT TYPE=SUBMIT VALUE="View  $CASE.trace2" class="$bcolor"> ( view $CASE.trace2 in new format )<br>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
<FORM ACTION="/util/edit2.pl">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<INPUT NAME=file VALUE="$DIR/$CASE.dope.trace2" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  $CASE.dope.trace2" class="$bcolor"> ( view $CASE.dope.trace2 in new format )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">

__STOP__
&reset;
#--------------------------------------------------------------
$mystep = 10;
&mark if ($step == $mystep);
&PassHiddenParms;
$OUT .=  <<__STOP__;
</FORM>
<FORM ACTION=/exec/executor.pl METHOD=POST>
<INPUT NAME=prog TYPE=HIDDEN VALUE="boltz_plotpl2 ">
<INPUT TYPE=SUBMIT VALUE="boltz_plots2 " class="$bcolor"> plot $CASE.trace2
( all plots are in postscript format  )
<br> Download ASCII files for plotting with your own plotting program </br> &nbsp;&nbsp;&nbsp;
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
__STOP__
&reset;
&PassHiddenParms;

foreach (@files) {
    if ($_ =~ /\.trace/ ) { 
     $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</a>";}

    }

    $OUT .= "<br>Download postscript files</br>";
foreach (@files) {    
    if ($_ =~ /\.ps/ ) { 
     $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</a>";}
                
    }
    
    
$OUT .=  <<__STOP__;
</FORM>
 </TD></TR>
__STOP__
#--------

}
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&




$OUT .= <<__STOP__;

<TR ><TD bgcolor=$green >
<FORM ACTION="/util/saveboltz2.pl">
__STOP__

$mystep = 11;
&mark if ($step == $mystep);
&PassHiddenParms;
$OUT .=  <<__STOP__;


<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
<INPUT TYPE=HIDDEN NAME="o" VALUE="1">
<INPUT NAME=redir VALUE="/exec/boltz2.pl?SID=$SID" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="save_boltz2" class="$bcolor">
 with name: $indent <INPUT NAME="savename" VALUE= $CASE$myspinopt>   (   For example : $CASE$myspinopt  )       <br>
 
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>


__STOP__
###########
&reset;
##########################################
$OUT.=<<__STOP__;

</TABLE>

__STOP__
$OUT .=  <<__STOP__;
<DIV ALIGN=RIGHT ><FONT SIZE="-2" >\&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </FONT></DIV>
__STOP__


PrintPage("Context",$OUT);


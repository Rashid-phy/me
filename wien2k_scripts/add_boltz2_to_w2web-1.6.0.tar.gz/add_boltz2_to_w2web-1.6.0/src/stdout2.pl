#!/usr/bin/perl

require "../../libs/w2web.pl";

&GetInput;
&GetSession;
$next="return to BoltzTraP2 setup ";
$nexturl="/exec/boltz2.pl?SID=$SID";
$nextinteractive=1;




if ( -e "$DIR/run.integrate" ) {
	$runing="<b>Please wait</b>:
            <br> Reload in reverse order,  the \" integrate \" finished when the following line is appeared in first line :</br>
            <b> (INFO  || JSON output file: $CASE.btj ) </b><br></br>";
}elsif( -e "$DIR/run.interpolate" ) {
	$runing="<b>Please wait</b>:
            <br> Reload in reverse order, the \" interpolate \" finished when the following is appeared in first line:</br>
            <b>( INFO  || saving the results took 'time..' s) </b><br></br>";
}elsif ( -e "$DIR/run.dope" ) {
	$runing="<b>Please wait</b>:
            <br> Reload in reverse order, the \" dope \" finished when the following is appeared in first line:</br>
            <b>( INFO  || Hall coefficient output file: $CASE.dope.halltens ) </b><br></br>";
}


$pidnum=qx( ps -A | grep btp2 | cut -f1 -d?);

if ($pidnum ){
if (-e "$DIR/.running.interpolate" or -e "$DIR/.running.integrate" or -e "$DIR/.running.dope" or -e "$DIR/.running.plot") {

$OUT .= <<__STOP__;

<table  align="right" >
<tr><td align="middle" >
<h6><b> To kill All running BoltzTraP2 in any where.<br><b>  PID:   $pidnum </b></h6>
</table>
<table  align="right" >
<tr><td align="middle" bgcolor=$gray  padding=25px>
<FORM  ACTION=/util/stdout2.pl METHOD=POST >
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=stopb VALUE=3>
<INPUT TYPE=SUBMIT  VALUE=" Stop Btp2 " > 
</FORM>

</td></tr>

</table>

<h3 >Show STDOUT  </h3>
$runing

</tr></br>
<table bgcolor=$green>
<tr><td bgcolor=$gray>
<FORM ACTION=/util/stdout2.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=reload VALUE=1>
<INPUT TYPE=SUBMIT VALUE="reload">
</FORM>
</td><td bgcolor=$gray>
<FORM ACTION=/util/stdout2.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=reverse VALUE=2>
<INPUT TYPE=SUBMIT VALUE="reload in reverse order">
</FORM>
</Td>
__STOP__

if (-e "$DIR/.running.interpolate" or -e "$DIR/.running.integrate" or -e "$DIR/.running.dope" or -e "$DIR/.running.plot") {}else{
$OUT .= <<__STOP__;
<TD bgcolor=$gray >
<FORM ACTION=/exec/next.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=next VALUE=$next>
<INPUT TYPE=HIDDEN NAME=nexturl VALUE=$nexturl>
<INPUT TYPE=HIDDEN NAME=interactive VALUE=$nextinteractive>
<INPUT TYPE=SUBMIT VALUE="$next">
</FORM>
</td>
__STOP__

}
$OUT .= <<__STOP__;
</tr>
</table>
<pre>
__STOP__

if ($reverse) {
	$umps = qx( tac $DIR/STDOUT );
} elsif ($reload ) {
	$umps = qx( cat $DIR/STDOUT );

#$umps =~ s/\n/<br>/;
} 
if ( $stopb ) {
   if ( $pidnum ){
qx( echo " &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& ">> $DIR/STDOUT);
qx( echo " STOP btp2 ">> $DIR/STDOUT);
qx( echo " BoltzTraP2:is stopped. ">> $DIR/STDOUT);
qx( echo " &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& ">> $DIR/STDOUT);
$stp=qx( killall btp2 );

}
}

$OUT .= <<__STOP__;
$stp
__STOP__

$OUT .= <<__STOP__;
$umps
</pre>
__STOP__
}
} else {
$OUT = <<__STOP__;




<h3 >Show STDOUT  </h3>
$runing
</tr></br>
<table bgcolor=$green>
<tr><td bgcolor=$gray>
<FORM ACTION=/util/stdout2.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=reload VALUE=1>
<INPUT TYPE=SUBMIT VALUE="reload">
</FORM>
</td><td bgcolor=$gray>
<FORM ACTION=/util/stdout2.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=HIDDEN NAME=reverse VALUE=2>
<INPUT TYPE=SUBMIT VALUE="reload in reverse order">
</FORM>
</Td>
__STOP__

if (-e "$DIR/.running.interpolate" or -e "$DIR/.running.integrate" or -e "$DIR/.running.dope" or -e "$DIR/.running.plot") {}else{
$OUT .= <<__STOP__;
<TD bgcolor=$gray >
<FORM ACTION=/exec/next.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=next VALUE=$next>
<INPUT TYPE=HIDDEN NAME=nexturl VALUE=$nexturl>
<INPUT TYPE=HIDDEN NAME=interactive VALUE=$nextinteractive>
<INPUT TYPE=SUBMIT VALUE="$next">
</FORM>
</td>
__STOP__

}
$OUT .= <<__STOP__;

</tr>
</table>
<pre>
__STOP__

if ($reverse) {
	$umps = qx( tac $DIR/STDOUT );
} elsif ($reload ) {
	$umps = qx( cat $DIR/STDOUT );

#$umps =~ s/\n/<br>/;
} 
if ( $stopb ) {
   if ( $pidnum ){
qx( echo " &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& ">> $DIR/STDOUT);
qx( echo " STOP btp2 ">> $DIR/STDOUT);
qx( echo " All runnig BoltzTraP2 are stopped. ">> $DIR/STDOUT);
qx( echo " &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& ">> $DIR/STDOUT);
$stp=qx( killall btp2 );

}
}

$OUT .= <<__STOP__;
$stp
__STOP__

$OUT .= <<__STOP__;
$umps
</pre>
__STOP__
}
PrintPage("Delete file", $OUT);

#!/usr/bin/perl

$manual=0;

require "../libs/w2web.pl";
&GetInput;
&GetSession;


if ($manual) {
  $refresh=-1;
  $icons=0;
}


$tm = localtime;

use POSIX qw(strftime);
$tm = strftime("%H:%M:%S", localtime);


$flag=1;
$semfile="$tempdir/$SID-$$.find";


if ( -e $semfile ) {
	$flag=0;
}

system "touch $semfile";

@result = glob("$DIR/.running*");
$run = "idle";
$run = "<img src=\"/art/sleep.gif\" hspace=0>" if $icons;
foreach $i (@result) {
    if ( -e $i ) {
	$running = "running";
	$running = "stop SCF" if ( -e "$DIR/.stop" ) ;
	$running = "stop MINI" if ( -e "$DIR/.minstop" ) ;
	$running .= "|fulldiag" if ( -e "$DIR/.fulldiag" ) ;
	$run = "<b><a href=\"/util/dir.pl?SID=$SID&dir=$DIR&ext=run\" target=main>$running</a></b>";
	$runadd = qx( cat $i | tail -1 );
	$runadd =~ s/ *//;
	$run .= " ($runadd)";
	$run .= "<img src=\"/art/run-ani.gif\">" if $icons;
	$topcolor=$red;
    }
}
######### check running Btp2 ##########
if ( -e "$DIR/STDOUT" ){
$tsterror1=qx(grep usage:' 'btp2 $DIR/STDOUT );
$tsterror2=qx(grep ValueError $DIR/STDOUT );
$tsterror3=qx(grep TypeError: $DIR/STDOUT );
$tsterror4=qx(grep python $DIR/STDOUT );
$tsterror5=qx(grep "ERROR   â" $DIR/STDOUT );
if ( $tsterror1  or $tsterror2 or $tsterror3 or $tsterror4 or $tsterror5 or $tsterror5) {
  qx(rm $DIR/.running.interpolate);
  qx(rm $DIR/.running.integrate);
  qx(rm $DIR/.running.dope);
  qx(rm $DIR/.running.plot);
 # qx(cp  $DIR/STDOUT  $DIR/btp2.error);
 # qx( echo " " > $DIR/STDOUT);
  }
  
 $tstfermi= qx(grep Refined "$DIR/STDOUT"| cut -f2 -d:);
if ($tstfermi ){
  qx(grep Refined "$DIR/STDOUT" > $DIR/refinedEf );
   $fermi  .=2*qx(grep Refined "$DIR/refinedEf"| cut -f2 -d:);
 #  $header .=qx( echo " $fermi     # Refined Fermi level in Ry "     >$DIR/$CASE.infermi );
  }
    
}

$tste = qx( exec wc -l btp2.error);
	if ($tste >= 1) {
	    $run = "<a href=\"/util/dir.pl?SID=$SID&dir=$DIR&ext=error\" target=main>error</a>";
	    $run = "<img src=\"/art/stupid2.gif\"> <a href=\"/util/dir.pl?SID=$SID&dir=$DIR&ext=error\" target=main>error</a>" if $icons;
	    $topcolor=$darkred;
	}
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 

$tst=qx( ps -A | grep btp2 );
 if ( $tst) {
   unless ( -e  "$DIR/.running.interpolate" and -e  "$DIR/.running.integrate" and -e  "$DIR/.running.dope" and -e  "$DIR/.running.plot") {
    qx( echo "running Btp2 in cmd" >$DIR/.running.btp2cmd );
   } 
 } else {
   qx(rm $DIR/.running.interpolate);
   qx(rm $DIR/.running.integrate);
   qx(rm $DIR/.running.dope);
   qx(rm $DIR/.running.plot);
   qx(rm $DIR/.running.btp2cmd);
 }
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 

@result = glob("$DIR/*.error");
foreach $i (@result) {
    if ( -z $i ) {	
	# this is good, no error
    } else {
	$test = qx( exec wc -l $i );
	if ($test > 1) {
	    $run = "<a href=\"/util/dir.pl?SID=$SID&dir=$DIR&ext=error\" target=main>error</a>";
	    $run = "<img src=\"/art/stupid2.gif\"> <a href=\"/util/dir.pl?SID=$SID&dir=$DIR&ext=error\" target=main>error</a>" if $icons;
	    $topcolor=$darkred;
	}
    }
}

# -----------------------------------------
# check for temporary files and clean up
# -----------------------------------------
$umps = qx(find $tempdir -cmin +$removetime -print ) if $flag;
$count=0;
foreach $i (split(/\n/,$umps)) {
    $count++;
    if ( -f $i) {
	system "rm $i";
    }
}
# -----------------------------------------

$run .= " (skipping find)" if !($flag);

# -----------------------------------------
# time-stamping session file
# -----------------------------------------
system "touch $sessionpath/$SID";
# -----------------------------------------

$renew = <<__STOP__;
<META HTTP-EQUIV="refresh" content="$refresh; URL=status.pl?SID=$SID">
<META HTTP-EQUIV="PRAGMA" CONTENT="no-cache">
<META HTTP-EQUIV="EXPIRES" CONTENT="now">
__STOP__

$OUT .=  <<__STOP__;
Content-type: text/html\n
<html>
<head>
   <title>WIEN2k</title>
$renew
</head>                                    
<link href="$css" rel="stylesheet">
</head>
<body bgcolor=$topcolor>
<div align=right>
<font size=-2>
<nobr>$tm $run</nobr><br>
__STOP__

if ($manual) {
    $OUT .=  <<__STOP__;
<a href="status.pl?SID=$SID&manual=1">refresh now</a>
|
<a hreF="status.pl?SID=$SID&manual=0">auto-refresh</a>
__STOP__
} else {
    $OUT .=  <<__STOP__;
<a href="status.pl?SID=$SID">refresh</a>
|
<a href="status.pl?SID=$SID&manual=1">no refresh</a>
__STOP__
}

$OUT .=  <<__STOP__;
</font>
</div>
</body>
</html>                          
__STOP__

print $OUT;

system "rm $semfile" if $flag;

#!/usr/bin/perl

require "../../libs/w2web.pl";
#$debug=1;
$spin="up";
$myspinopt="";
$name="";

&GetInput;
&GetSession;
$prefspace="scf";
&GetPrefs();

$OUT .= "<h2> Boltzmann Transport Properties (BoltzTraP) </h2>";

$next="continue with BoltzTraP setup ";
$nexturl="/exec/boltz.pl?SID=$SID";
$nextinteractive=1;

&InitTask();

&RequiredFile("intrans");

$OUT.="<TABLE>";

if ($plot) {
	$OUT .=  <<__STOP__;
<TR><TD class="task">

<A HREF="$nexturl">Show full menu</A>
</TD></TR>
__STOP__

} else {

	$OUT .=  <<__STOP__;

<TR><TD class="taskoption">
<FORM ACTION="/util/edit.pl">
<b>Required steps:</b><br>
__STOP__

&PassHiddenParms;
$OUT .=  <<__STOP__;

<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>

<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__


&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="kgen">
<INPUT TYPE=SUBMIT VALUE="x kgen">
Prepare a denser k-mesh

<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__

&PassHiddenParms;







$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapw1">
$myspin
<INPUT TYPE=SUBMIT VALUE="x lapw1  $myspinopt $mypara">
Create eigenvalues at denser k-mesh 

&nbsp;

__STOP__


    if($spinpol=~ /CHECKED/ && ! $PREFS{'so'} ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}


$OUT .=  <<__STOP__;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__


 if($spinpol=~ /CHECKED/ ) {
 $otherspin = "dn" if ($spin =~ /up/) ;
 $otherspin = "up" if ($spin =~ /dn/) ;
 
 
$OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>

__STOP__

&PassHiddenParms;
$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapw1">
<INPUT TYPE=HIDDEN NAME=spin VALUE=$otherspin>
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
<INPUT TYPE=SUBMIT VALUE="x lapw1  -$otherspin $mypara">
for both spins

__STOP__


if($spinpol=~ /CHECKED/ && ! $PREFS{'so'} ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}
$OUT .=  <<__STOP__;
$ni
</FORM>
__STOP__
}

if( $PREFS{'so'})  {
    $my_spinp = "no" ;
    $my_spinp = "yes" if ($spin =~ /dn/) ;
    if ($my_spinp =~ /no/) {
$OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;




$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x">
<INPUT NAME=prog TYPE=HIDDEN VALUE="lapwso ">
<INPUT TYPE=SUBMIT VALUE="x lapwso $myspinopt $mypara">
$myspin
Create eigenvalues with spin-orbit coupling
&nbsp;
__STOP__
    if($spinpol=~ /CHECKED/ ) {
	$OUT .=  "<INPUT NAME=orb TYPE=CHECKBOX $PREFS{'orb'}>&nbsp;orb&nbsp";
}
$OUT .=  <<__STOP__;
$ni
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
__STOP__
    } 
}

&PassHiddenParms;





##################################################################################"""""

if ( $mypara ) {

$OUT .=  <<__STOP__;
</TD></TR>
<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__

$OUT .=  <<__STOP__;

<b> needed only for run in parallel  :</b><br>

<INPUT NAME=prog TYPE=HIDDEN VALUE="gather_energy.pl $CASE $myspinopt">
<INPUT TYPE=SUBMIT VALUE="gather_energy.pl $CASE  $myspinopt ">
$myspin
To gather energy files ( ignore this msg:energy_??: No such file) 
<INPUT NAME=so TYPE=CHECKBOX $PREFS{'so'}>&nbsp;so&nbsp;

<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
__STOP__
}






######################################################"


















&PassHiddenParms;
$OUT .=  <<__STOP__;
</FORM>
</TD></TR>
<TR><TD class="task">
<b>BoltzTraP steps:</b><br>
<FORM ACTION="/util/edit.pl">
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>

<INPUT NAME=file VALUE="$DIR/$CASE.intrans" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="edit $CASE.intrans">
 (Insert Fermi level and the electron number   ( $CASE.scf2)   )
 
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>


<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__












&PassHiddenParms;
#/////////////////////////////////////////////////////////////////////////////////////////////////
if( $PREFS{'so'})  {
    $my_spinp = "no" ;
    $my_spinp = "yes" if ($spin =~ /dn/) ;
    if ($my_spinp =~ /no/) {
$OUT .=  <<__STOP__;
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__
&PassHiddenParms;


$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x_trans">
<INPUT NAME=prog TYPE=HIDDEN VALUE="BoltzTraP  -so ">
<INPUT TYPE=SUBMIT VALUE="x_trans BoltzTraP  -so ">
$myspin
Calculate Boltzman Transport Properties
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

<TR><TD class="task">
<TABLE>
<TD class="task">
<FORM ACTION="/util/edit.pl">
__STOP__
    } 
} else{

$OUT .=  <<__STOP__;
<INPUT NAME=precmd TYPE=HIDDEN VALUE="x_trans">
<INPUT NAME=prog TYPE=HIDDEN VALUE="BoltzTraP">
<INPUT TYPE=SUBMIT VALUE="x_trans BoltzTraP $myspinopt ">
$myspin
Calculate Boltzman Transport Properties
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>

<TR><TD class="task">
<TABLE>
<TD class="task">
<FORM ACTION="/util/edit.pl">

__STOP__
}
#//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


if ($myspinopt =~ /-up/) {

    &PassHiddenParms;

$OUT.=<<__STOP__;

<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.outputtrans" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  $CASE.outputtrans">
(  check output x_trans  ) &nbsp&nbsp&nbsp  &nbsp;&nbsp&nbsp;  &nbsp;&nbsp;&nbsp;
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD>
<TD class="task">

<FORM ACTION="/util/edit.pl">
__STOP__
&PassHiddenParms;

$OUT.=<<__STOP__;
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/upBoltzTraP.def" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  upBoltzTraP.def">
 (if there are an errors check input files  )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></tr>
</TABLE>

</TR>

<TR><TD class="task">
<FORM ACTION="/util/edit.pl">
__STOP__
&PassHiddenParms;


__STOP__

    } elsif ($myspinopt =~ /-dn/) {

    &PassHiddenParms;

$OUT.=<<__STOP__;

<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.outputtrans" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  $CASE.outputtrans">
(   check output x_trans   ) &nbsp&nbsp&nbsp  &nbsp;&nbsp&nbsp;  &nbsp;&nbsp;&nbsp;
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD>
<TD class="task">

<FORM ACTION="/util/edit.pl">
__STOP__
&PassHiddenParms;

$OUT.=<<__STOP__;
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/dnBoltzTraP.def" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  dnBoltzTraP.def">
 (if there are an errors check input files  )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></tr>
</TABLE>

</TR>

<TR><TD class="task">
<FORM ACTION="/util/edit.pl">
__STOP__
&PassHiddenParms;

__STOP__

} else {
&PassHiddenParms;

$OUT.=<<__STOP__;

<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.outputtrans" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  $CASE.outputtrans">
(   check output x_trans   ) &nbsp&nbsp&nbsp  &nbsp;&nbsp&nbsp;  &nbsp;&nbsp;&nbsp;
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD>
<TD class="task">

<FORM ACTION="/util/edit.pl">
__STOP__
&PassHiddenParms;

$OUT.=<<__STOP__;
<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/BoltzTraP.def" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  BoltzTraP.def">
 (if there are an errors check input files  )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></tr>
</TABLE>

</TR>

<TR><TD class="task">
<FORM ACTION="/util/edit.pl">
__STOP__
&PassHiddenParms;
   
   }
   
   


&PassHiddenParms;
$OUT .=  <<__STOP__;

<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT NAME=file VALUE="$DIR/$CASE.trace" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="View  $CASE.trace">
( view BoltzTraP results )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>
<TR><TD class="task">
<FORM ACTION=/exec/executor.pl METHOD=POST>
__STOP__


&PassHiddenParms;
$OUT .=  <<__STOP__;

<INPUT NAME=prog TYPE=HIDDEN VALUE="boltz_plotpl">
<INPUT TYPE=SUBMIT VALUE="boltz_plots ">
( all plots are in postscript format  )
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>
__STOP__
}

#####################################################

if($plot){
	$OUT .= <<__STOP__;
<b>We are in plot mode</b><br>
<TR><TD class="task">
__STOP__
	if($doit) {

		$plotfile="$tempdir/$SID-$$";
		$infile="$DIR/$CASE.";
		$titline=1;
		$delline=0;
                        $seltrace="";
                        $col3="";
                        $col4="";
                        $col5="";
                        $col6="";
                        $col7="";
                        $col8="";
                        $col9="";
                        $col10="";
                        $col11="";
                        $col12="";
                        $col13="";
     if ($col =~ /3/) {
                } elsif ($col =~ /3/) {                
		        $col3="selected";
		} elsif ($col =~ /4/) {
                        $col4="selected";
		} elsif ($col =~ /5/) {
                        $col5="selected";
		} elsif ($col =~ /6/) {
                        $col6="selected";
		} elsif ($col =~ /7/) {
                        $col7="selected";
                } elsif ($col =~ /8/) {
                        $col8="selected";
		} elsif ($col =~ /9/) {
                        $col9="selected";
		} elsif ($col =~ /10/) {
                        $col10="selected";
		} elsif ($col =~ /11/) {
                        $col11="selected";
                } elsif ($col =~ /12/) {
                        $col12="selected";
               } elsif ($col =~ /13/) {
                        $col13="selected";
		} 
     if($edoit) {
			$ecol1="";
                        $ecol2="";
            if ($ecol =~ /1/) {
                        $ecol1="selected";
	        } elsif ($ecol =~ /2/) {
                        $ecol2="selected"; 
                        }
		
        }		
		
		
		
		
		
		
		
    if ($selfile =~ /trace/) {
			$infile.="trace";
			$titline=1;
			$delline=1;
                        $seltrace="selected";
		}


	
		$test = qx(wc -l $infile);
		if ($test == 0) {
			$OUT .= "$infile is empty - no plot produced";
		} else {

			$tmp1 = "$DIR/:bolt1";
			$tmp2 = "$DIR/:bolt2";
                  if ($ecol == 1) {
			$units  = "ev";
			$xlabel = "chemical potential (Ef-Ef0) [eV]";
			$axis   = "yzeroaxis";
		} else {
		        $units  = "°K";
			$xlabel = "Temperature [°K]";
			$axis   = "yzeroaxis";
		
		
	           }
			$umps = qx(sed "1,${delline}d" $infile >$tmp1);
			$tmp  = qx(cat $infile | head -$titline | tail -1|cut -c3-8,15-192);
			@ylabels = split(" ",$tmp);
			$ylabel = $ylabels[$col-1];
			$title = "$infile column $col";

    unless(open(FILE,">$tmp2")) {
      &CGIError("Can't write file $fname.\n");
      exit;
    }
    print FILE <<__STOP__;
show all
set terminal png
set output '$plotfile.png'
set title '$title'
set style data lines
set xrange [$xmin:$xmax]
set yrange [$ymin:$ymax]
set xlabel "$xlabel"
set ylabel "$ylabel"

set $axis
$plotoptions
plot "$tmp1" using $ecol:$col  
set terminal postscript
set output '$plotfile.ps'
replot
__STOP__
			close(FILE);
			$umps = qx(cd $DIR;gnuplot $tmp2 2>&1);
			$OUT .= "<br><IMG SRC=/tmp/$SID-$$.png><br clear=all><br>";
			$OUT .= "<A HREF=/tmp/$SID-$$.ps>Download hardcopy in PostScript format</A
>";

	
		    }
#		$OUT .= $myform1;
#		&PassHiddenParms;
#		$OUT .= $myform2
	}
$myform1 =  <<__STOP__;
<FORM ACTION=/exec/boltz.pl METHOD=POST>
__STOP__
$myform2 =  <<__STOP__;
<SELECT NAME="selfile">
<option $seltrace value="trace">$CASE.trace

</SELECT>
<SELECT NAME="ecol">
<option $ecol1 value=1>1
<option $ecol2 value=2>2
</SELECT>
<INPUT TYPE=hidden NAME=edoit VALUE="1">


</SELECT>
<SELECT NAME="col">
<option $col3  value=3>03
<option $col4  value=4>04
<option $col5  value=5>05
<option $col6  value=6>06
<option $col7  value=7>07
<option $col8  value=8>08
<option $col9  value=9>09
<option $col10 value=10>10
<option $col11 value=11>11
<option $col12 value=12>12
<option $col13 value=13>13
</SELECT>
<INPUT TYPE=hidden NAME=doit VALUE="1">
<INPUT TYPE=hidden NAME=plot VALUE="1">
<INPUT TYPE=SUBMIT VALUE="plot">


Plot Transport properties
<br>
Set ranges (optional):
<br>
xmin=<INPUT NAME=xmin VALUE="$xmin" SIZE=5>
xmax=<INPUT NAME=xmax VALUE="$xmax" SIZE=5>
ymin=<INPUT NAME=ymin VALUE="$ymin" SIZE=5>
ymax=<INPUT NAME=ymax VALUE="$ymax" SIZE=5>
<INPUT TYPE=HIDDEN NAME="spin" VALUE="$spin">
</FORM>
</TD></TR>
__STOP__

#old doit beginn
# else {
		$OUT .= $myform1;
		&PassHiddenParms;
		$OUT .= $myform2

#	}
} else {
	$OUT .= <<__STOP__;
<TR><TD class="task">
<FORM ACTION=/exec/boltz.pl METHOD=POST>
__STOP__
&PassHiddenParms;
    opendir(DIR1, $DIR);
    @files = sort(readdir(DIR1));
    closedir(DIR1);
$OUT .=  <<__STOP__;
<INPUT TYPE=hidden NAME=plot VALUE="1">
$myspin
<INPUT TYPE=SUBMIT VALUE="plot   $CASE.trace">
Plot Boltzmann Transport Properties &nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp; download ASCII files for plotting with your own plotting program <br> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
__STOP__
 
    foreach (@files) {
    if ($_ =~ /\.ps/ ) { 
     $OUT .= "<a href=\"/util/download.pl?SID=$SID&file=$DIR/$_\">$_</a>";}
                
    }
$OUT .= <<__STOP__;
</FORM>
</TD></TR>
__STOP__
}

#####################################################





$OUT .= <<__STOP__;

<TR><TD class="task">
<FORM ACTION="/util/saveboltz.pl">
__STOP__


&PassHiddenParms;
$OUT .=  <<__STOP__;


<INPUT NAME=SID VALUE=$SID TYPE=HIDDEN>
<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
<INPUT TYPE=HIDDEN NAME="o" VALUE="1">
<INPUT NAME=redir VALUE="/exec/boltz.pl?SID=$SID" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="save_boltz">
 with name: $indent <INPUT NAME="savename" VALUE= $CASE$myspinopt>   (   For example : $CASE$myspinopt  )       <br>
 
<INPUT TYPE=hidden NAME=next VALUE="$next">
<INPUT TYPE=hidden NAME=nexturl VALUE="$nexturl">
</FORM>
</TD></TR>


__STOP__
#####################################################
$OUT.=<<__STOP__;

</TABLE>

__STOP__
$OUT .=  <<__STOP__;
<DIV ALIGN=RIGHT ><FONT SIZE="-2" >\@G.Benabdellah&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </FONT></DIV>
<DIV ALIGN=RIGHT ><FONT SIZE="-2" >============&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></DIV>                                  
__STOP__


PrintPage("Context",$OUT);


#!/usr/bin/perl

require "../../libs/w2web.pl";
$doit=0;

&GetInput;
&GetSession;

if (!$doit) {

$OUT = <<__STOP__;
<h3>save_boltz</h3>
<FORM ACTION="/util/saveboltz.pl" METHOD=POST>
<INPUT TYPE=HIDDEN NAME="SID" VALUE="$SID">
<INPUT TYPE=HIDDEN NAME="doit" VALUE="1">
Save name or directory: 
$indent <INPUT NAME="savename"><br>
<br>
<INPUT TYPE=SUBMIT VALUE="save">
</FORM>

__STOP__

} else {
$OUT .= "<h3>save_boltz $savename</h3>";
	
	if (!$savename) {
		$OUT .= "<b>ERROR</b> no save name given!";
	} else {

		$cmdline = "save_boltz";
		$cmdline .= " $savename";

		$OUT .= "$cmdline";

		$out = qx(cd $DIR; $cmdline);
		$OUT .= "<pre>$out</pre>" ;
	}

}



PrintPage("save_boltz", $OUT);

#!/usr/bin/perl

require "../../libs/w2web.pl";


$debug=0;

$interactive=0;
$inputok=1;
$proginput="";
$again="";
$precmd="";
$prog="";

&GetInput();
&GetSession();
&ExeTypes();



if (!($FORM{'prog'})) {
	$OUT .= <<__STOP__;
<P>
<B>No program selected!</B>
</P>
<A HREF=$ENV{'HTTP_REFERER'}>return to previous page</A>

__STOP__
	PrintPage("Context",$OUT);
	exit;
}

if ($FORM{'INPUT1'} eq "")
{
    $need = 0;
    foreach $i (@needinput)
    {
#		if ( $i =~ /$FORM{'prog'}/){;
#		if ( $FORM{'prog'} =~ /$i/){;
	if ( $FORM{'prog'} eq "$i" )
	{;
	 $need = 1;
	 $OUT .= "NEED INPUT!!!" if $debug;
	 $inputok=0;
	 &$i;
	 $OUT .= qq/<INPUT TYPE=SUBMIT VALUE="Execute!">/;
     }
    }
}
else
{
########################################################################################## boltztrap 2
if ($FORM{'precmd'}=~/btp2/)
	{
	   
	    my $num=$FORM{num};
	    my $cmdstring=" ";
        
       
	   if ( $num ne "" )
	    {
		$cmdstring.="-n ";
		$cmdstring.="$num ";
	    }
	    $FORM{precmd}.=$cmdstring; 
	    $FORM{num}="";
	    
	    qx( rm $DIR/btp2.error );
    }
#///////////////////////////////////////
if ($FORM{'prog'}=~/interpolate/)
	{
	   
	    my $o=$FORM{INPUT1};
	    my $e=$FORM{INPUT2};
	    my $E=$FORM{INPUT3};
	    my $k=$FORM{INPUT4};
	    my $m=$FORM{INPUT5};
	    my $d=$FORM{INPUT6};
	    my $cmdstring=" ";
	    qx ( echo "NWORKERS=  $num" >$DIR/btp2input);
        qx ( echo "Emin=  $e" >>$DIR/btp2input);
        qx ( echo "Emax=  $E" >>$DIR/btp2input);
        qx ( echo "Kpoint=  $k" >>$DIR/btp2input);
        qx ( echo "Multiplier= $m" >>$DIR/btp2input);	   
	    
	    
	    qx( rm $DIR/run.interpolate );
	    qx( rm $DIR/run.integrate );
	    qx( rm $DIR/run.dope );
	    qx( echo " please waite interpolate is running"> $DIR/run.interpolate );
	    qx( echo "interpolate is running"> $DIR/.running.interpolate); 
	   if ( $o ne "" )
	    {
		$cmdstring.="-o ";
		$cmdstring.="$o ";
	    }
	    
	    if ( $e ne "" )
	    {
		;
		$cmdstring.="-e ";
		$cmdstring.="$e  ";
	    }
	    if ( $E ne "" )
	    {
		$cmdstring.="-E ";
		$cmdstring.="$E ";
	    }
	     if ( $k ne "" )
	    {
		$cmdstring.="-k ";
		$cmdstring.="$k ";
	    }
	    if ( $m ne "" )
	    {
		$cmdstring.="-m ";
		$cmdstring.="$m ";
        }
        if ( $d ne "" )
	    {
		$cmdstring.=" ";
		$cmdstring.="$d ";
            }
	    $FORM{prog}.=$cmdstring; #f�gt -emin ... etc. an das Programm an
	    $FORM{INPUT1}="";
	    $FORM{INPUT2}="";
	    $FORM{INPUT3}="";
	    $FORM{INPUT4}="";
	    $FORM{INPUT5}="";
	    $FORM{INPUT6}="";
	}

if ($FORM{'prog'}=~/integrate/)
	{
	    
	    my $in=$FORM{INPUT1};
	   # my $pp=$FORM{INPUT1};
	    my $b=$FORM{INPUT2};
	    my $tORl=$FORM{INPUT3};
        my $scissor=$FORM{INPUT4};
	    my $temp=$FORM{INPUT5};
       qx ( echo "NWORKERS=  $num" >$DIR/btp2input2);
	   qx ( echo "TEMPERATUR=  $temp" >>$DIR/btp2input2);
	   qx ( echo "BINS=  $b" >>$DIR/btp2input2);
	   qx ( echo "SCISSOR=  $scissor" >>$DIR/btp2input2);
	    qx( rm $DIR/run.interpolate );
	    qx( rm $DIR/run.integrate );
	    qx( rm $DIR/run.dope );
	    qx( echo " plaise waite integrate is running"> $DIR/run.integrate );
	    qx( echo " integrate is running"> $DIR/.running.integrate );
	   if ( $in ne "" )
	    {
		$cmdstring.="   ";
		$cmdstring.="  $in ";
	    }
	   if ( $scissor != 0  and $scissor ne "" )
	   {
		$cmdstring.=" -s ";
		$cmdstring.="  $scissor ";
	   }
	    
	    if ( $b ne "" and $b != 0 )
	    {
		$cmdstring.=" -b ";
		$cmdstring.=" $b  ";
	    }
	    if ( $tORl  )
	    {
		$cmdstring.=" $tORl ";
		$cmdstring.="  ";
	    }
	     
	    if ( $temp ne "" )
	    {
		$cmdstring.=" ";
		$cmdstring.=" $temp ";
        }
        $FORM{prog}.=$cmdstring; #f�gt -emin ... etc. an das Programm an
	    $FORM{INPUT1}="";
	    $FORM{INPUT2}="";
	    $FORM{INPUT3}="";
	    $FORM{INPUT4}="";
	    $FORM{INPUT5}="";
    }
if ($FORM{'prog'}=~/dope/)
	{
	    
	    my $in=$FORM{INPUT1};
	    my $b=$FORM{INPUT2};
	    my $tORl=$FORM{INPUT3};
        my $scissor=$FORM{INPUT4};
	    my $temp=$FORM{INPUT5};
	    my $dp=$FORM{INPUT6};
	     
       qx ( echo "NWORKERS=  $num" >$DIR/btp2input3);
	   qx ( echo "TEMPERATUR=  $temp" >>$DIR/btp2input3);
	    qx ( echo "DOPING=  $dp" >>$DIR/btp2input3);
	   qx ( echo "BINS=  $b" >>$DIR/btp2input3);
	   qx ( echo "SCISSOR=  $scissor" >>$DIR/btp2input3);   
	     
	    qx( rm $DIR/run.interpolate );
	    qx( rm $DIR/run.integrate );
	    qx( rm $DIR/run.dope );
	    qx( echo " plaise waite dope is running"> $DIR/run.dope );
        qx( echo " dope is running"> $DIR/.running.dope );
	   if ( $in ne "" )
	    {
		$cmdstring.="   ";
		$cmdstring.="  $in ";
	    }
	  if ( $scissor ne "" and $scissor != 0)
	   {
		$cmdstring.=" -s ";
		$cmdstring.="  $scissor ";
	   }
	    
	    if ( $b ne "" and  $b != 0 )
	    {
		$cmdstring.=" -b ";
		$cmdstring.=" $b  ";
	    }
	    if ( $tORl  )
	    {
		$cmdstring.=" $tORl ";
		$cmdstring.="  ";
	    }
	     
	    if ( $temp ne "" )
	    {
		$cmdstring.=" ";
		$cmdstring.=" $temp ";
        }
        if( $dp ne "" ){
        $cmdstring.=" ";
		$cmdstring.=" $dp ";
        }
        $FORM{prog}.=$cmdstring; #f�gt -emin ... etc. an das Programm an
	    $FORM{INPUT1}="";
	    $FORM{INPUT2}="";
	    $FORM{INPUT3}="";
	    $FORM{INPUT4}="";
	    $FORM{INPUT5}="";
	    $FORM{INPUT6}="";
    }

if ($FORM{'prog'}=~/plot/)
	{
	    
	    my $compr=$FORM{INPUT1};
	    my $UorT=$FORM{INPUT2};
	   	my $s=$FORM{INPUT3};
	    my $btj=$FORM{INPUT4};
        my $paramater=$FORM{INPUT5};
	    
	    qx( rm $DIR/run.interpolate );
	    qx( rm $DIR/run.integrate );
	    qx( rm $DIR/run.dope );
	    qx( echo " btp2  plot is running"> $DIR/run.plot );
        qx( echo " bplot running"> $DIR/.running.dope );
	   
	   if ( $compr ne "" )
	    {
		$cmdstring.="  -c  ";
		$cmdstring.="  \'$compr\' ";
		}
	   if ( $UorT  ne "" ) 	    {
		$cmdstring.=" $UorT ";
		$cmdstring.="  ";
	    }
       if ( $s ne "" )        {
		$cmdstring.=" -s  ";
		$cmdstring.=" $s ";
	    }
	    if ( $btj ne "" )     {
		$cmdstring.=" ";
		$cmdstring.=" $btj ";
        }
        if( $paramater ne "" ){
        $cmdstring.=" ";
		$cmdstring.=" $paramater ";
        }
        $FORM{prog}.=$cmdstring; #f�gt -emin ... etc. an das Programm an
	    $FORM{INPUT1}="";
	    $FORM{INPUT2}="";
	    $FORM{INPUT3}="";
	    $FORM{INPUT4}="";
	    $FORM{INPUT5}="";

$std="<b> Please wait: Plot will be showed in external windows </b>";

    }



 
#////////////////////////////////////////////////////////////////////////////////////////end btp2

}

if ($inputok) {
	# create commandline
	$cmd = "";
	$opts = "";
	
	if ($FORM{'precmd'}) {
#		$opts .= " -c" if ($complex =~ /on|CHECKED/);
		$cmd ="$FORM{'precmd'} $FORM{'prog'} $opts";
	} else {
		$cmd = "$FORM{'prog'}";
	}
	$again = <<__STOP__;
<H4>Execute another command line:</H4>
<p>
<table><tr valign=bottom><td>
<FORM ACTION=/exec/b_executor.pl METHOD=POST>
<INPUT NAME=prog TYPE=INPUT SIZE=50>
<BR>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT TYPE=SUBMIT VALUE="Run!">
$exetypes2
</SELECT>
</FORM>
</td><td>
<FORM ACTION=/exec/b_executor.pl METHOD=POST>
<INPUT NAME="prog" VALUE="$cmd" TYPE=HIDDEN>
<INPUT TYPE=HIDDEN NAME=SID VALUE=$SID>
<INPUT NAME="interactive" VALUE="$interactive" TYPE=HIDDEN>
<INPUT TYPE=SUBMIT VALUE="Repeat: $cmd">
</FORM>
</td></tr></table>
</p>
__STOP__


# if $next is set, just overwrite the $again....
if ($next) {
	$interactive=$nextinteractive;
	$again = <<__STOP__;
<H4>Continue with</H4>
<table><tr valign=bottom><td>
<FORM ACTION=/exec/next.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=next VALUE=$next>
<INPUT TYPE=HIDDEN NAME=nexturl VALUE=$nexturl>
<INPUT TYPE=HIDDEN NAME=interactive VALUE=$nextinteractive>
<INPUT TYPE=SUBMIT VALUE="$next">
</FORM>
</td></tr></table>
__STOP__
}

	$OUT .= <<__STOP__;
<P>
<br>
Commandline: <b>$cmd</b><BR>
</br>

__STOP__

if ($exetype =~ /interactive/ ) {
} elsif ($exetype eq "" ) {
} else {
$cmdfile="$DIR/.command.$SID.$$";
unless(open(FILE,">$cmdfile")) {
	&CGIError("Can't write file $fname.\n");
	exit;
}

print FILE <<__STOP__;
#!/bin/sh
date
cd $DIR
echo '$proginput'|$cmd >$DIR/STDOUT 2>&1
rm $cmdfile
__STOP__
close(FILE);
$umps=qx(chmod +x $cmdfile);
}
	if ($exetype =~ /background/ ) {$exetype =""}
	if ($exetype =~ /interactive/ ) {$interactive=1;}

	system "rm $DIR/STDOUT" if ( -e "$DIR/STDOUT");                     
	if ($interactive) {
		if ($proginput) {
			$OUT .= "proginput \n" if $debug;
			$umps = qx( cd $DIR;echo "$proginput"|$cmd  2>&1);
		}else {
			$OUT .= "no input \n" if $debug;
			$umps = qx( cd $DIR;$cmd 2>&1);
		}
		$OUT .= "$umps\n";
	} else {
	if ($exetype =~ /%f/) {
		$exetype=~ s/%f/ $cmdfile/;
		#$OUT.="we did: cd $DIR;$exetype &";
		system "cd $DIR;$exetype &";
	} else {
		#$OUT.= "cd $DIR;$exetype echo '$proginput'|$cmd >$DIR/STDOUT 2>&1 &";
		system "cd $DIR;$exetype echo '$proginput'|$cmd >$DIR/STDOUT 2>&1 &";
		system "cd $DIR;rm $cmdfile";
	}
}
#		system "cd $DIR;echo '$proginput'|$cmd >$DIR/STDOUT 2>&1 &";
#		$OUT .= "commandline sent to system for execution";
#
#	}

	$OUT .= <<__STOP__;
</PRE>
</td></tr></table>
</p>
__STOP__

if ($interactive){
} else {
$OUT0 = <<__STOP__;
	<A HREF="/util/stdout2.pl?SID=$SID">View STDOUT</A> to monitor the progress of this command

__STOP__
}

$again0 = <<__STOP__;

<table><tr valign=bottom><td>
<FORM ACTION=/exec/next.pl METHOD=POST>
<INPUT TYPE=HIDDEN NAME=next VALUE=$next>
<INPUT TYPE=HIDDEN NAME=nexturl VALUE=$nexturl>
<INPUT TYPE=HIDDEN NAME=interactive VALUE=$nextinteractive>
<INPUT TYPE=SUBMIT VALUE="$next">
</FORM>
</td></tr></table>
__STOP__

if ($FORM{'prog'}=~/plot/){
$OUT .= <<__STOP__;
$again0
$std
$fig
__STOP__
} else{

$OUT .= <<__STOP__;
$OUT0
$again
__STOP__
}
}

PrintPage("Context",$OUT);


